package Graficos;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JButton;
import java.awt.GridBagLayout;
import java.awt.GridBagConstraints;
import java.awt.Insets;
import javax.swing.BoxLayout;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import java.awt.Font;

public class primeraVentana extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField txtDisplay;
	private JButton btnAC;
	private JButton btnComma;

	/**
	 * Launch the application.
	 */
	//  FUNCIONES DE LA CALCULADORA
	private String current = "0";     
	private Double acc = null;        
	private String op = null;         
	private boolean waitingNext = false; 
	

	// FORMATO
	private String toScreen(String internal) {
	    return internal.replace('.', ',');
	}

	private String fromScreen(String screen) {
	    return screen.replace(',', '.');
	}

	private void setDisplay(String internal) {
	    if ("Error".equals(internal)) {
	        txtDisplay.setText("Error");
	        return;
	    }

	    String out = internal;

	    if (out.contains(".")) {
	        if (!out.endsWith(".")) {
	            out = out.replaceAll("([.][0-9]*?)0+$", "$1");
	        }
	    }

	    txtDisplay.setText(toScreen(out));  
	    current = internal;
	}

	// OPERACIONES BASICAS 
	private String compute(double a, double b, String oper) {
	    double r;
	    switch (oper) {
	        case "+": r = a + b; break;
	        case "-": r = a - b; break;
	        case "*": r = a * b; break;
	        case "/": 
	            if (b == 0.0) return "Error";
	            r = a / b; 
	            break;
	        default:  r = b;
	    }
	    // redondeo 
	    r = Math.round((r + Double.MIN_VALUE) * 1e12) / 1e12;
	    return Double.toString(r);
	}

	// ENTRADA DE NUMEROS
	private void pressDigit(String d) {
	    if (waitingNext) {
	        waitingNext = false;
	        current = "0";
	    }

	    if (",".equals(d)) d = ".";

	    if ("0".equals(current) && ".".equals(d)) {
	        current = "0.";
	        setDisplay(current);
	        return;
	    }

	    if (".".equals(d) && current.contains(".")) {
	        return;
	    }

	    if ("0".equals(current) && !".".equals(d)) {
	        current = d;
	    } else if ("-0".equals(current) && !".".equals(d)) {
	        current = "-" + d;
	    } else {
	        current += d;
	    }

	    setDisplay(current);
	}

	//  OPERADORES 
	private void pressOperator(String nextOp) {
	    double curr = Double.parseDouble(fromScreen(txtDisplay.getText()));
	    if (acc == null) {
	        acc = curr;
	    } else if (!waitingNext && op != null) {
	        String res = compute(acc, curr, op);
	        if (res.equals("Error")) {
	            setDisplay("Error");
	            acc = null; op = null; waitingNext = false;
	            return;
	        }
	        acc = Double.valueOf(res);
	        setDisplay(res);
	    }
	    op = nextOp;
	    waitingNext = true;
	}

	private void pressEquals() {
	    if (op == null || acc == null) return;
	    double curr = Double.parseDouble(fromScreen(txtDisplay.getText()));
	    String res = compute(acc, curr, op);
	    setDisplay(res);
	    acc = null;
	    op = null;
	    waitingNext = false;
	}

	// TECLAS ESPECIALES 
	private void pressClear() {
	    current = "0";
	    acc = null;
	    op = null;
	    waitingNext = false;
	    setDisplay("0");
	}

	private void pressBack() {
	    if (waitingNext) return;
	    String scr = txtDisplay.getText();
	    if (scr.equals("Error")) { setDisplay("0"); return; }
	    String in = fromScreen(scr);
	    if (in.length() <= 1 || (in.startsWith("-") && in.length()==2)) {
	        setDisplay("0");
	    } else {
	        setDisplay(in.substring(0, in.length()-1));
	    }
	}

	private void pressSign() {
	    String in = current;
	    if (in.equals("0")) return;
	    if (in.startsWith("-")) in = in.substring(1);
	    else in = "-" + in;
	    setDisplay(in);
	}

	private void pressPercent() {
	    String in = current;
	    try {
	        double v = Double.parseDouble(in) / 100.0;
	        setDisplay(Double.toString(v));
	    } catch (NumberFormatException ex) {
	        
	    }
	}

	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					primeraVentana frame = new primeraVentana();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public primeraVentana() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 413, 238);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
	

		setContentPane(contentPane);
		GridBagLayout gbl_contentPane = new GridBagLayout();
		gbl_contentPane.columnWidths = new int[]{149, 85, 10, 0, 0, 0};
		gbl_contentPane.rowHeights = new int[]{21, 0, 0, 0, 0, 0, 0, 0};
		gbl_contentPane.columnWeights = new double[]{0.0, 1.0, 0.0, 0.0, 0.0, Double.MIN_VALUE};
		gbl_contentPane.rowWeights = new double[]{0.0, 1.0, 0.0, 0.0, 0.0, 0.0, 0.0, Double.MIN_VALUE};
		contentPane.setLayout(gbl_contentPane);
		
		JPanel panel_1 = new JPanel();
		GridBagConstraints gbc_panel_1 = new GridBagConstraints();
		gbc_panel_1.gridwidth = 5;
		gbc_panel_1.insets = new Insets(0, 0, 5, 0);
		gbc_panel_1.fill = GridBagConstraints.BOTH;
		gbc_panel_1.gridx = 0;
		gbc_panel_1.gridy = 0;
		contentPane.add(panel_1, gbc_panel_1);
		
		txtDisplay = new JTextField();
		txtDisplay.setBorder(new EmptyBorder(0, 0, 0, 0));
		txtDisplay.setFont(new Font("Tahoma", Font.PLAIN, 36));
		txtDisplay.setHorizontalAlignment(SwingConstants.RIGHT);
		txtDisplay.setText("0");
		txtDisplay.setAlignmentY(0.1f);
		txtDisplay.setAlignmentX(0.1f);
		panel_1.add(txtDisplay);
		txtDisplay.setColumns(10);
		
		JPanel panel = new JPanel();
		GridBagConstraints gbc_panel = new GridBagConstraints();
		gbc_panel.insets = new Insets(0, 0, 5, 5);
		gbc_panel.anchor = GridBagConstraints.WEST;
		gbc_panel.gridx = 2;
		gbc_panel.gridy = 0;
		contentPane.add(panel, gbc_panel);
		panel.setLayout(new BoxLayout(panel, BoxLayout.X_AXIS));
		
		
		btnComma = new JButton(",");
		btnComma.setFont(new Font("Tahoma", Font.PLAIN, 20));
		GridBagConstraints gbc_btnComma = new GridBagConstraints();
		gbc_btnComma.weighty = 1.0;
		gbc_btnComma.fill = GridBagConstraints.BOTH;
		gbc_btnComma.weightx = 1.0;
		gbc_btnComma.insets = new Insets(2, 2, 2, 2);
		gbc_btnComma.gridx = 0;
		gbc_btnComma.gridy = 2;
		contentPane.add(btnComma, gbc_btnComma);
		
		btnAC = new JButton("AC");
		btnAC.setFont(new Font("Tahoma", Font.PLAIN, 20));
		GridBagConstraints gbc_btnAC = new GridBagConstraints();
		gbc_btnAC.weighty = 1.0;
		gbc_btnAC.weightx = 1.0;
		gbc_btnAC.fill = GridBagConstraints.BOTH;
		gbc_btnAC.insets = new Insets(2, 2, 2, 2);
		gbc_btnAC.gridx = 1;
		gbc_btnAC.gridy = 2;
		contentPane.add(btnAC, gbc_btnAC);
		
		JButton btnPorc = new JButton("%");
		btnPorc.setFont(new Font("Tahoma", Font.PLAIN, 20));
		btnPorc.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		GridBagConstraints gbc_btnPorc = new GridBagConstraints();
		gbc_btnPorc.weighty = 1.0;
		gbc_btnPorc.weightx = 1.0;
		gbc_btnPorc.fill = GridBagConstraints.BOTH;
		gbc_btnPorc.insets = new Insets(2, 2, 2, 2);
		gbc_btnPorc.gridx = 2;
		gbc_btnPorc.gridy = 2;
		contentPane.add(btnPorc, gbc_btnPorc);
		
		JButton btnDiv = new JButton("/");
		btnDiv.setFont(new Font("Tahoma", Font.PLAIN, 20));
		btnDiv.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		GridBagConstraints gbc_btnDiv = new GridBagConstraints();
		gbc_btnDiv.weighty = 1.0;
		gbc_btnDiv.weightx = 1.0;
		gbc_btnDiv.fill = GridBagConstraints.BOTH;
		gbc_btnDiv.insets = new Insets(2, 2, 2, 2);
		gbc_btnDiv.gridx = 4;
		gbc_btnDiv.gridy = 2;
		contentPane.add(btnDiv, gbc_btnDiv);
		
		JButton btn7 = new JButton("7");
		btn7.setFont(new Font("Tahoma", Font.PLAIN, 20));
		GridBagConstraints gbc_btn7 = new GridBagConstraints();
		gbc_btn7.weighty = 1.0;
		gbc_btn7.weightx = 1.0;
		gbc_btn7.fill = GridBagConstraints.BOTH;
		gbc_btn7.insets = new Insets(2, 2, 2, 2);
		gbc_btn7.gridx = 0;
		gbc_btn7.gridy = 3;
		contentPane.add(btn7, gbc_btn7);
		
		JButton btn8 = new JButton("8");
		btn8.setFont(new Font("Tahoma", Font.PLAIN, 20));
		GridBagConstraints gbc_btn8 = new GridBagConstraints();
		gbc_btn8.weighty = 1.0;
		gbc_btn8.weightx = 1.0;
		gbc_btn8.fill = GridBagConstraints.BOTH;
		gbc_btn8.insets = new Insets(2, 2, 2, 2);
		gbc_btn8.gridx = 1;
		gbc_btn8.gridy = 3;
		contentPane.add(btn8, gbc_btn8);
		
		JButton btn9 = new JButton("9");
		btn9.setFont(new Font("Tahoma", Font.PLAIN, 20));
		GridBagConstraints gbc_btn9 = new GridBagConstraints();
		gbc_btn9.weighty = 1.0;
		gbc_btn9.weightx = 1.0;
		gbc_btn9.fill = GridBagConstraints.BOTH;
		gbc_btn9.insets = new Insets(2, 2, 2, 2);
		gbc_btn9.gridx = 2;
		gbc_btn9.gridy = 3;
		contentPane.add(btn9, gbc_btn9);
		
		JButton btnMul = new JButton("X");
		btnMul.setFont(new Font("Tahoma", Font.PLAIN, 20));
		GridBagConstraints gbc_btnMul = new GridBagConstraints();
		gbc_btnMul.weighty = 1.0;
		gbc_btnMul.weightx = 1.0;
		gbc_btnMul.fill = GridBagConstraints.BOTH;
		gbc_btnMul.insets = new Insets(2, 2, 2, 2);
		gbc_btnMul.gridx = 4;
		gbc_btnMul.gridy = 3;
		contentPane.add(btnMul, gbc_btnMul);
		
		JButton btn4 = new JButton("4");
		btn4.setFont(new Font("Tahoma", Font.PLAIN, 20));
		GridBagConstraints gbc_btn4 = new GridBagConstraints();
		gbc_btn4.weighty = 1.0;
		gbc_btn4.weightx = 1.0;
		gbc_btn4.fill = GridBagConstraints.BOTH;
		gbc_btn4.insets = new Insets(2, 2, 2, 2);
		gbc_btn4.gridx = 0;
		gbc_btn4.gridy = 4;
		contentPane.add(btn4, gbc_btn4);
		
		JButton btn5 = new JButton("5");
		btn5.setFont(new Font("Tahoma", Font.PLAIN, 20));
		GridBagConstraints gbc_btn5 = new GridBagConstraints();
		gbc_btn5.weighty = 1.0;
		gbc_btn5.weightx = 1.0;
		gbc_btn5.fill = GridBagConstraints.BOTH;
		gbc_btn5.insets = new Insets(2, 2, 2, 2);
		gbc_btn5.gridx = 1;
		gbc_btn5.gridy = 4;
		contentPane.add(btn5, gbc_btn5);
		
		JButton btn6 = new JButton("6");
		btn6.setFont(new Font("Tahoma", Font.PLAIN, 20));
		GridBagConstraints gbc_btn6 = new GridBagConstraints();
		gbc_btn6.weighty = 1.0;
		gbc_btn6.weightx = 1.0;
		gbc_btn6.fill = GridBagConstraints.BOTH;
		gbc_btn6.insets = new Insets(2, 2, 2, 2);
		gbc_btn6.gridx = 2;
		gbc_btn6.gridy = 4;
		contentPane.add(btn6, gbc_btn6);
		
		JButton btnMenos = new JButton("-");
		btnMenos.setFont(new Font("Tahoma", Font.PLAIN, 20));
		GridBagConstraints gbc_btnMenos = new GridBagConstraints();
		gbc_btnMenos.weighty = 1.0;
		gbc_btnMenos.weightx = 1.0;
		gbc_btnMenos.fill = GridBagConstraints.BOTH;
		gbc_btnMenos.insets = new Insets(2, 2, 2, 2);
		gbc_btnMenos.gridx = 4;
		gbc_btnMenos.gridy = 4;
		contentPane.add(btnMenos, gbc_btnMenos);
		
		JButton btn1 = new JButton("1");
		btn1.setFont(new Font("Tahoma", Font.PLAIN, 20));
		GridBagConstraints gbc_btn1 = new GridBagConstraints();
		gbc_btn1.weighty = 1.0;
		gbc_btn1.weightx = 1.0;
		gbc_btn1.fill = GridBagConstraints.BOTH;
		gbc_btn1.insets = new Insets(2, 2, 2, 2);
		gbc_btn1.gridx = 0;
		gbc_btn1.gridy = 5;
		contentPane.add(btn1, gbc_btn1);
		
		JButton btn2 = new JButton("2");
		btn2.setFont(new Font("Tahoma", Font.PLAIN, 20));
		btn2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		GridBagConstraints gbc_btn2 = new GridBagConstraints();
		gbc_btn2.weighty = 1.0;
		gbc_btn2.weightx = 1.0;
		gbc_btn2.fill = GridBagConstraints.BOTH;
		gbc_btn2.insets = new Insets(2, 2, 2, 2);
		gbc_btn2.gridx = 1;
		gbc_btn2.gridy = 5;
		contentPane.add(btn2, gbc_btn2);
		
		JButton btn3 = new JButton("3");
		btn3.setFont(new Font("Tahoma", Font.PLAIN, 20));
		GridBagConstraints gbc_btn3 = new GridBagConstraints();
		gbc_btn3.weighty = 1.0;
		gbc_btn3.weightx = 1.0;
		gbc_btn3.fill = GridBagConstraints.BOTH;
		gbc_btn3.insets = new Insets(2, 2, 2, 2);
		gbc_btn3.gridx = 2;
		gbc_btn3.gridy = 5;
		contentPane.add(btn3, gbc_btn3);
		
		JButton btnMas = new JButton("+");
		btnMas.setFont(new Font("Tahoma", Font.PLAIN, 20));
		GridBagConstraints gbc_btnMas = new GridBagConstraints();
		gbc_btnMas.weighty = 1.0;
		gbc_btnMas.weightx = 1.0;
		gbc_btnMas.fill = GridBagConstraints.BOTH;
		gbc_btnMas.insets = new Insets(2, 2, 2, 2);
		gbc_btnMas.gridx = 4;
		gbc_btnMas.gridy = 5;
		contentPane.add(btnMas, gbc_btnMas);
		
		JButton btnSign = new JButton("+/-");
		btnSign.setFont(new Font("Tahoma", Font.PLAIN, 20));
		GridBagConstraints gbc_btnSign = new GridBagConstraints();
		gbc_btnSign.fill = GridBagConstraints.BOTH;
		gbc_btnSign.insets = new Insets(2, 2, 2, 2);
		gbc_btnSign.gridx = 0;
		gbc_btnSign.gridy = 6;
		contentPane.add(btnSign, gbc_btnSign);
		
		JButton btn0 = new JButton("0");
		btn0.setFont(new Font("Tahoma", Font.PLAIN, 20));
		btn0.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		GridBagConstraints gbc_btn0 = new GridBagConstraints();
		gbc_btn0.weighty = 1.0;
		gbc_btn0.weightx = 1.0;
		gbc_btn0.fill = GridBagConstraints.BOTH;
		gbc_btn0.insets = new Insets(2, 2, 2, 2);
		gbc_btn0.gridx = 1;
		gbc_btn0.gridy = 6;
		contentPane.add(btn0, gbc_btn0);
		
		JButton btnBack = new JButton("<-");
		btnBack.setFont(new Font("Tahoma", Font.PLAIN, 20));
		GridBagConstraints gbc_btnBack = new GridBagConstraints();
		gbc_btnBack.weighty = 1.0;
		gbc_btnBack.weightx = 1.0;
		gbc_btnBack.fill = GridBagConstraints.BOTH;
		gbc_btnBack.insets = new Insets(2, 2, 2, 2);
		gbc_btnBack.gridx = 2;
		gbc_btnBack.gridy = 6;
		contentPane.add(btnBack, gbc_btnBack);
		
		JButton btnIgual = new JButton("=");
		btnIgual.setFont(new Font("Tahoma", Font.PLAIN, 20));
		GridBagConstraints gbc_btnIgual = new GridBagConstraints();
		gbc_btnIgual.weightx = 1.0;
		gbc_btnIgual.fill = GridBagConstraints.BOTH;
		gbc_btnIgual.weighty = 1.0;
		gbc_btnIgual.insets = new Insets(2, 2, 2, 2);
		gbc_btnIgual.gridx = 4;
		gbc_btnIgual.gridy = 6;
		contentPane.add(btnIgual, gbc_btnIgual);
		
		// --- Conexiones de botones ---
		setDisplay("0");

		btn0.addActionListener(e -> pressDigit("0"));
		btn1.addActionListener(e -> pressDigit("1"));
		btn2.addActionListener(e -> pressDigit("2"));
		btn3.addActionListener(e -> pressDigit("3"));
		btn4.addActionListener(e -> pressDigit("4"));
		btn5.addActionListener(e -> pressDigit("5"));
		btn6.addActionListener(e -> pressDigit("6"));
		btn7.addActionListener(e -> pressDigit("7"));
		btn8.addActionListener(e -> pressDigit("8"));
		btn9.addActionListener(e -> pressDigit("9"));
		
		

		btnMas.addActionListener(e -> pressOperator("+"));
		btnMenos.addActionListener(e -> pressOperator("-"));
		btnMul.addActionListener(e -> pressOperator("*"));
		btnDiv.addActionListener(e -> pressOperator("/"));

		btnIgual.addActionListener(e -> pressEquals());
		btnAC.addActionListener(e -> pressClear());
		btnBack.addActionListener(e -> pressBack());
		btnSign.addActionListener(e -> pressSign());
		btnPorc.addActionListener(e -> pressPercent());
		
		txtDisplay.setEditable(false);          
		btnComma.addActionListener(e -> {
		    System.out.println("PULSADA COMA");   //prueba para poder ver si la coma funciona :(
		    pressDigit(",");
		
		});

	}
	
	

}
